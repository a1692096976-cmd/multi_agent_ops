import json
from datetime import datetime
from typing import Any, Dict, List, Optional
from app.db.database import get_connection


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def row_to_dict(row):
    return dict(row) if row else None


def create_project(data: Dict[str, Any]) -> Dict[str, Any]:
    current = now_iso()
    with get_connection() as conn:
        cursor = conn.execute(
            """
            INSERT INTO projects(name, goal, product, audience, budget, tone, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                data["name"], data["goal"], data["product"], data["audience"],
                data["budget"], data["tone"], "created", current, current
            ),
        )
        project_id = cursor.lastrowid
        row = conn.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
        return row_to_dict(row)


def list_projects() -> List[Dict[str, Any]]:
    with get_connection() as conn:
        rows = conn.execute("SELECT * FROM projects ORDER BY id DESC").fetchall()
        return [row_to_dict(r) for r in rows]


def get_project(project_id: int) -> Optional[Dict[str, Any]]:
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
        return row_to_dict(row)


def update_project_status(project_id: int, status: str) -> None:
    with get_connection() as conn:
        conn.execute(
            "UPDATE projects SET status = ?, updated_at = ? WHERE id = ?",
            (status, now_iso(), project_id),
        )


def add_log(project_id: int, agent_name: str, step: str, message: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    with get_connection() as conn:
        cursor = conn.execute(
            """
            INSERT INTO agent_logs(project_id, agent_name, step, message, payload, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (project_id, agent_name, step, message, json.dumps(payload, ensure_ascii=False), now_iso()),
        )
        row = conn.execute("SELECT * FROM agent_logs WHERE id = ?", (cursor.lastrowid,)).fetchone()
        item = row_to_dict(row)
        item["payload"] = json.loads(item["payload"])
        return item


def list_logs(project_id: int) -> List[Dict[str, Any]]:
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT * FROM agent_logs WHERE project_id = ? ORDER BY id ASC",
            (project_id,),
        ).fetchall()
        result = []
        for r in rows:
            item = row_to_dict(r)
            item["payload"] = json.loads(item["payload"])
            result.append(item)
        return result


def clear_artifacts(project_id: int) -> None:
    with get_connection() as conn:
        conn.execute("DELETE FROM artifacts WHERE project_id = ?", (project_id,))


def add_artifact(project_id: int, artifact_type: str, title: str, content: Dict[str, Any]) -> Dict[str, Any]:
    with get_connection() as conn:
        cursor = conn.execute(
            """
            INSERT INTO artifacts(project_id, artifact_type, title, content, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (project_id, artifact_type, title, json.dumps(content, ensure_ascii=False), now_iso()),
        )
        row = conn.execute("SELECT * FROM artifacts WHERE id = ?", (cursor.lastrowid,)).fetchone()
        item = row_to_dict(row)
        item["content"] = json.loads(item["content"])
        return item


def list_artifacts(project_id: int) -> List[Dict[str, Any]]:
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT * FROM artifacts WHERE project_id = ? ORDER BY id ASC",
            (project_id,),
        ).fetchall()
        result = []
        for r in rows:
            item = row_to_dict(r)
            item["content"] = json.loads(item["content"])
            result.append(item)
        return result
