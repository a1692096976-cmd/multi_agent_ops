from typing import Any, Dict, List
from fastapi import HTTPException
from app.db import repository as repo
from app.core.orchestrator import Orchestrator


def create_project(data: Dict[str, Any]) -> Dict[str, Any]:
    return repo.create_project(data)


def list_projects() -> List[Dict[str, Any]]:
    return repo.list_projects()


def get_project_detail(project_id: int) -> Dict[str, Any]:
    project = repo.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")
    return {
        "project": project,
        "artifacts": repo.list_artifacts(project_id),
        "logs": repo.list_logs(project_id),
    }


def run_workflow(project_id: int) -> Dict[str, Any]:
    project = repo.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")
    orchestrator = Orchestrator()
    result = orchestrator.run(project)
    return {
        "project_id": project_id,
        "status": "completed",
        "result": result,
    }


def list_logs(project_id: int) -> List[Dict[str, Any]]:
    project = repo.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")
    return repo.list_logs(project_id)


def list_artifacts(project_id: int) -> List[Dict[str, Any]]:
    project = repo.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")
    return repo.list_artifacts(project_id)


def export_project(project_id: int) -> Dict[str, Any]:
    project = repo.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")
    return {
        "project": project,
        "artifacts": repo.list_artifacts(project_id),
        "logs": repo.list_logs(project_id),
    }
