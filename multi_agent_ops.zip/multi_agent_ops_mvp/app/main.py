from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from app.config import settings
from app.db.database import init_db
from app.schemas import ProjectCreate
from app.services import project_service

app = FastAPI(title=settings.APP_NAME)

app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")


@app.on_event("startup")
def on_startup():
    init_db()


@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "app_name": settings.APP_NAME})


@app.get("/health")
def health():
    return {"status": "ok", "app": settings.APP_NAME, "llm_provider": settings.LLM_PROVIDER}


@app.post("/api/projects")
def create_project(payload: ProjectCreate):
    return project_service.create_project(payload.model_dump())


@app.get("/api/projects")
def list_projects():
    return project_service.list_projects()


@app.get("/api/projects/{project_id}")
def get_project(project_id: int):
    return project_service.get_project_detail(project_id)


@app.post("/api/projects/{project_id}/run")
def run_project(project_id: int):
    return project_service.run_workflow(project_id)


@app.get("/api/projects/{project_id}/logs")
def get_logs(project_id: int):
    return project_service.list_logs(project_id)


@app.get("/api/projects/{project_id}/artifacts")
def get_artifacts(project_id: int):
    return project_service.list_artifacts(project_id)


@app.get("/api/projects/{project_id}/export")
def export_project(project_id: int):
    return project_service.export_project(project_id)
