from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional
from datetime import datetime


class ProjectCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=80)
    goal: str = Field(..., min_length=10, max_length=1000)
    product: str = Field(..., min_length=2, max_length=120)
    audience: str = Field(..., min_length=2, max_length=200)
    budget: str = Field(default="低预算", max_length=80)
    tone: str = Field(default="专业、清晰、有转化感", max_length=80)


class ProjectOut(BaseModel):
    id: int
    name: str
    goal: str
    product: str
    audience: str
    budget: str
    tone: str
    status: str
    created_at: str
    updated_at: str


class WorkflowRunResponse(BaseModel):
    project_id: int
    status: str
    result: Dict[str, Any]


class AgentLogOut(BaseModel):
    id: int
    project_id: int
    agent_name: str
    step: str
    message: str
    payload: Dict[str, Any]
    created_at: str


class ArtifactOut(BaseModel):
    id: int
    project_id: int
    artifact_type: str
    title: str
    content: Dict[str, Any]
    created_at: str
