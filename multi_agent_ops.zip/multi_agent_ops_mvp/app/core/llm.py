import json
import re
from typing import Any, Dict, List
from app.config import settings


class BaseLLM:
    def generate(self, system: str, prompt: str, schema_hint: str = "") -> str:
        raise NotImplementedError


class LocalRuleLLM(BaseLLM):
    """
    本地规则 LLM：
    不依赖外部 API，用可控模板模拟大模型输出，方便 MVP 直接运行。
    """

    def generate(self, system: str, prompt: str, schema_hint: str = "") -> str:
        text = f"{system}\n{prompt}\n{schema_hint}".lower()

        if "planner" in text or "规划" in text:
            return json.dumps({
                "strategy": "先完成目标拆解，再完成用户洞察、渠道选择、内容生产、排期执行和数据复盘。",
                "milestones": [
                    "第 1 天：明确定位和核心卖点",
                    "第 2-3 天：完成内容素材和种子用户触达",
                    "第 4-5 天：集中发布和社群转化",
                    "第 6 天：根据数据优化话术和渠道",
                    "第 7 天：复盘并沉淀 SOP"
                ],
                "tasks": [
                    {"name": "提炼目标用户和核心痛点", "priority": "高", "owner": "ResearchAgent"},
                    {"name": "制定渠道组合和内容主题", "priority": "高", "owner": "ChannelAgent"},
                    {"name": "生成多渠道运营文案", "priority": "高", "owner": "CopywriterAgent"},
                    {"name": "审核风险与转化漏洞", "priority": "中", "owner": "ReviewAgent"},
                    {"name": "生成七天排期表", "priority": "高", "owner": "SchedulerAgent"},
                    {"name": "预测指标并给出复盘方案", "priority": "中", "owner": "AnalystAgent"}
                ]
            }, ensure_ascii=False, indent=2)

        if "research" in text or "用户洞察" in text:
            return json.dumps({
                "personas": [
                    {
                        "name": "效率型用户",
                        "pain_points": ["时间有限", "希望快速看到结果", "不愿意学习复杂工具"],
                        "motivations": ["节省时间", "降低试错成本", "获得可复制模板"]
                    },
                    {
                        "name": "结果导向用户",
                        "pain_points": ["缺少专业判断", "担心投入没有回报", "希望看到案例"],
                        "motivations": ["提升转化", "获得数据反馈", "增强确定性"]
                    }
                ],
                "core_insights": [
                    "用户更关注是否能直接解决问题，而不只是功能是否丰富。",
                    "早期传播需要突出低门槛、可立即体验和真实效果。",
                    "需要用案例、前后对比、限时福利降低首次尝试成本。"
                ],
                "value_proposition": "用更低成本、更短时间完成原本需要多人协作的运营执行工作。"
            }, ensure_ascii=False, indent=2)

        if "channel" in text or "渠道" in text:
            return json.dumps({
                "channels": [
                    {
                        "name": "小红书/短内容平台",
                        "goal": "获取冷启动曝光",
                        "actions": ["发布痛点型笔记", "做前后对比图", "引导评论区领取模板"],
                        "content_angle": "真实案例 + 节省时间 + 可复制模板"
                    },
                    {
                        "name": "微信群/社群",
                        "goal": "促成第一批转化",
                        "actions": ["发布体验名额", "收集反馈", "进行一对一答疑"],
                        "content_angle": "限时福利 + 群内反馈 + 快速体验"
                    },
                    {
                        "name": "公众号/长文",
                        "goal": "建立信任",
                        "actions": ["输出方法论文章", "放置案例和使用流程", "引导私信或表单"],
                        "content_angle": "系统方法 + 操作路径 + 数据结果"
                    },
                    {
                        "name": "邮件/短信",
                        "goal": "激活已有线索",
                        "actions": ["发送体验邀请", "提醒福利截止", "推送案例复盘"],
                        "content_angle": "明确利益点 + 低打扰提醒"
                    }
                ],
                "funnel": [
                    "内容曝光",
                    "评论/私信互动",
                    "领取模板或试用",
                    "社群承接",
                    "转化注册",
                    "复盘留存"
                ]
            }, ensure_ascii=False, indent=2)

        if "copywriter" in text or "文案" in text:
            return json.dumps({
                "copies": [
                    {
                        "channel": "小红书",
                        "title": "我用一个自动化运营系统，把 3 小时工作压缩到 15 分钟",
                        "body": "以前做活动运营，要先想目标、拆渠道、写文案、排日期，最后还要复盘数据。现在只要输入一句运营目标，系统会自动生成完整方案，包括用户画像、渠道动作、推广文案和 7 天排期。适合预算不高但执行任务很多的小团队。想看模板可以留言：运营。",
                        "cta": "评论区回复「运营」，领取 7 天运营排期模板。"
                    },
                    {
                        "channel": "社群",
                        "title": "限时开放 20 个体验名额",
                        "body": "我们正在测试一个多 Agent 运营自动化系统，可以自动帮你拆目标、写文案、做排期和生成复盘建议。现在开放 20 个免费体验名额，只需要提供一个运营目标，就能生成一份完整方案。",
                        "cta": "有需要的同学可以直接私信我。"
                    },
                    {
                        "channel": "公众号",
                        "title": "小团队如何用 AI 完成一场完整运营活动？",
                        "body": "很多运营活动失败，并不是因为想法不好，而是目标拆解、内容生产、渠道执行和数据复盘之间没有形成闭环。多 Agent 协作的价值在于把这些环节拆成多个专业角色，让系统像一个小型运营团队一样协作。",
                        "cta": "文末可领取完整 MVP 演示和运营模板。"
                    },
                    {
                        "channel": "邮件",
                        "title": "你的下一场运营活动，可以先让 AI 生成初稿",
                        "body": "你好，我们做了一个多 Agent 运营自动化系统。它可以根据你的活动目标，自动生成用户洞察、渠道策略、推广文案、执行排期和指标预测，帮助你更快完成运营方案初稿。",
                        "cta": "点击预约体验，获取你的第一份自动化运营方案。"
                    }
                ]
            }, ensure_ascii=False, indent=2)

        if "review" in text or "审核" in text:
            return json.dumps({
                "risk_level": "中低",
                "risks": [
                    {
                        "type": "效果承诺风险",
                        "description": "避免使用“保证转化”“一定增长”等绝对化表述。",
                        "suggestion": "改成“预计提升效率”“有机会降低整理成本”等更稳妥表达。"
                    },
                    {
                        "type": "信息完整性风险",
                        "description": "体验名额、领取方式、适用人群需要说清楚。",
                        "suggestion": "每条文案补充具体行动方式和适用边界。"
                    },
                    {
                        "type": "转化链路风险",
                        "description": "如果只有曝光内容，没有承接路径，容易造成流量浪费。",
                        "suggestion": "统一使用评论关键词、表单或私信作为承接入口。"
                    }
                ],
                "approved": True,
                "final_note": "文案整体可用于 MVP 冷启动，但发布前建议根据具体行业再替换案例细节。"
            }, ensure_ascii=False, indent=2)

        if "scheduler" in text or "排期" in text:
            days = []
            for i in range(1, 8):
                actions = [
                    "梳理目标与素材",
                    "发布第一批种草内容",
                    "社群承接与答疑",
                    "集中触达潜在线索",
                    "优化话术并二次发布",
                    "收集反馈和案例",
                    "复盘数据并沉淀 SOP",
                ]
                days.append({
                    "day": f"第 {i} 天",
                    "theme": actions[i-1],
                    "channels": ["社群", "小红书", "公众号"] if i in [2, 5] else ["社群", "私信/邮件"],
                    "owner": ["运营负责人", "内容负责人", "数据负责人"][i % 3],
                    "deliverables": [
                        f"{actions[i-1]}执行记录",
                        "当日数据截图",
                        "用户反馈摘录"
                    ],
                    "kpi": {
                        "exposure": 800 + i * 250,
                        "click": 50 + i * 18,
                        "conversion": 8 + i * 3
                    }
                })
            return json.dumps({"calendar": days}, ensure_ascii=False, indent=2)

        if "analyst" in text or "分析" in text:
            return json.dumps({
                "forecast": {
                    "total_exposure": 11800,
                    "total_click": 870,
                    "estimated_conversions": 146,
                    "conversion_rate": "12% - 18%",
                    "confidence": "中等"
                },
                "metrics": [
                    "内容曝光量",
                    "评论/私信数",
                    "表单提交数",
                    "注册或试用数",
                    "社群留存率",
                    "用户反馈有效率"
                ],
                "optimization": [
                    "如果曝光高但私信低，优化标题和 CTA。",
                    "如果私信高但注册低，优化落地页或体验门槛。",
                    "如果注册后留存低，增加模板、案例和一对一引导。",
                    "保留高互动内容结构，用于第二轮复制发布。"
                ],
                "next_actions": [
                    "沉淀一份标准运营 SOP。",
                    "整理 3 个真实案例作为下一轮内容素材。",
                    "建立用户反馈标签，指导后续产品迭代。"
                ]
            }, ensure_ascii=False, indent=2)

        return json.dumps({"message": "本地模型已生成通用运营建议。"}, ensure_ascii=False, indent=2)


class OpenAILLM(BaseLLM):
    def __init__(self):
        if not settings.OPENAI_API_KEY:
            raise RuntimeError("未配置 OPENAI_API_KEY")
        from openai import OpenAI
        self.client = OpenAI(api_key=settings.OPENAI_API_KEY)

    def generate(self, system: str, prompt: str, schema_hint: str = "") -> str:
        response = self.client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": prompt + "\n\n" + schema_hint},
            ],
            temperature=0.4,
        )
        return response.choices[0].message.content or ""


def get_llm() -> BaseLLM:
    if settings.LLM_PROVIDER == "openai":
        return OpenAILLM()
    return LocalRuleLLM()


def safe_json_loads(text: str) -> Dict[str, Any]:
    """
    尝试从 LLM 输出中提取 JSON。
    """
    try:
        return json.loads(text)
    except Exception:
        match = re.search(r"\{[\s\S]*\}", text)
        if match:
            try:
                return json.loads(match.group(0))
            except Exception:
                pass
    return {"raw": text}
