from typing import Any, Dict, List
from app.core.llm import get_llm
from app.core.memory import BlackboardMemory
from app.agents.planner import PlannerAgent
from app.agents.research import ResearchAgent
from app.agents.channel import ChannelAgent
from app.agents.copywriter import CopywriterAgent
from app.agents.review import ReviewAgent
from app.agents.scheduler import SchedulerAgent
from app.agents.analyst import AnalystAgent
from app.db import repository as repo


class Orchestrator:
    """
    多 Agent 编排器：
    控制 Agent 执行顺序，维护共享记忆，并记录每一步日志。
    """

    def __init__(self):
        llm = get_llm()
        self.agents = [
            ("plan", PlannerAgent(llm), "目标拆解"),
            ("research", ResearchAgent(llm), "用户洞察"),
            ("channels", ChannelAgent(llm), "渠道策略"),
            ("copies", CopywriterAgent(llm), "内容生产"),
            ("review", ReviewAgent(llm), "风险审核"),
            ("schedule", SchedulerAgent(llm), "执行排期"),
            ("analysis", AnalystAgent(llm), "数据预测与复盘"),
        ]

    def run(self, project: Dict[str, Any]) -> Dict[str, Any]:
        memory = BlackboardMemory()
        memory.set("project", project, "system")

        repo.update_project_status(project["id"], "running")
        repo.add_log(
            project["id"],
            "Orchestrator",
            "workflow_start",
            "多 Agent 工作流开始执行。",
            {"project": project},
        )

        try:
            for key, agent, step in self.agents:
                repo.add_log(
                    project["id"],
                    agent.name,
                    "start",
                    f"{step}开始。",
                    {"input_keys": list(memory.snapshot().keys())},
                )

                result = agent.run(project, memory)
                memory.set(key, result, agent.name)

                repo.add_log(
                    project["id"],
                    agent.name,
                    "finish",
                    f"{step}完成。",
                    {"result": result},
                )

                if key == "review" and result.get("approved") is False:
                    repo.add_log(
                        project["id"],
                        "Orchestrator",
                        "blocked",
                        "审核未通过，流程终止。",
                        {"review": result},
                    )
                    repo.update_project_status(project["id"], "blocked")
                    break

            final_result = self._build_final_result(project, memory)
            repo.clear_artifacts(project["id"])
            self._save_artifacts(project["id"], final_result)

            repo.update_project_status(project["id"], "completed")
            repo.add_log(
                project["id"],
                "Orchestrator",
                "workflow_finish",
                "多 Agent 工作流执行完成。",
                {"artifact_types": list(final_result.keys())},
            )
            return final_result

        except Exception as exc:
            repo.update_project_status(project["id"], "failed")
            repo.add_log(
                project["id"],
                "Orchestrator",
                "workflow_error",
                "工作流执行失败。",
                {"error": str(exc)},
            )
            raise

    def _build_final_result(self, project: Dict[str, Any], memory: BlackboardMemory) -> Dict[str, Any]:
        return {
            "overview": {
                "project_name": project["name"],
                "product": project["product"],
                "audience": project["audience"],
                "goal": project["goal"],
                "budget": project["budget"],
                "tone": project["tone"],
            },
            "plan": memory.get("plan", {}),
            "research": memory.get("research", {}),
            "channels": memory.get("channels", {}),
            "copies": memory.get("copies", {}),
            "review": memory.get("review", {}),
            "schedule": memory.get("schedule", {}),
            "analysis": memory.get("analysis", {}),
            "memory_timeline": memory.timeline,
        }

    def _save_artifacts(self, project_id: int, result: Dict[str, Any]) -> None:
        titles = {
            "overview": "项目总览",
            "plan": "运营规划",
            "research": "用户洞察",
            "channels": "渠道策略",
            "copies": "运营文案",
            "review": "风险审核",
            "schedule": "执行排期",
            "analysis": "数据预测与复盘",
            "memory_timeline": "Agent 协作轨迹",
        }
        for key, value in result.items():
            repo.add_artifact(project_id, key, titles.get(key, key), value if isinstance(value, dict) else {"items": value})
