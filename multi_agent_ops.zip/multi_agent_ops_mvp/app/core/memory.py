from typing import Any, Dict, List


class BlackboardMemory:
    """
    黑板记忆机制：
    多个 Agent 不直接耦合，而是把中间结果写入共享黑板。
    后续 Agent 从黑板中读取上下文继续加工。
    """

    def __init__(self):
        self.state: Dict[str, Any] = {}
        self.timeline: List[Dict[str, Any]] = []

    def set(self, key: str, value: Any, agent: str = "system") -> None:
        self.state[key] = value
        self.timeline.append({"agent": agent, "action": "set", "key": key, "value": value})

    def get(self, key: str, default: Any = None) -> Any:
        return self.state.get(key, default)

    def append(self, key: str, value: Any, agent: str = "system") -> None:
        if key not in self.state:
            self.state[key] = []
        self.state[key].append(value)
        self.timeline.append({"agent": agent, "action": "append", "key": key, "value": value})

    def snapshot(self) -> Dict[str, Any]:
        return dict(self.state)
