let selectedProjectId = null;
let selectedArtifact = null;

function toast(message) {
  const el = document.getElementById("toast");
  el.textContent = message;
  el.classList.remove("hidden");
  setTimeout(() => el.classList.add("hidden"), 3000);
}

function openCreatePanel() {
  document.getElementById("createPanel").classList.remove("hidden");
}

function closeCreatePanel() {
  document.getElementById("createPanel").classList.add("hidden");
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    headers: {"Content-Type": "application/json"},
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `请求失败：${res.status}`);
  }
  return res.json();
}

async function loadProjects() {
  const list = document.getElementById("projectList");
  list.innerHTML = "<p class='muted'>加载中...</p>";
  const projects = await api("/api/projects");
  if (!projects.length) {
    list.innerHTML = "<p class='muted'>暂无项目</p>";
    return;
  }
  list.innerHTML = projects.map(p => `
    <div class="project-item" onclick="loadProject(${p.id})">
      <strong>${escapeHtml(p.name)}</strong>
      <p>${escapeHtml(p.goal).slice(0, 80)}${p.goal.length > 80 ? "..." : ""}</p>
      <span class="badge">${statusText(p.status)}</span>
    </div>
  `).join("");
}

async function createProject() {
  const payload = {
    name: value("name"),
    product: value("product"),
    audience: value("audience"),
    budget: value("budget"),
    goal: value("goal"),
    tone: value("tone"),
  };
  const project = await api("/api/projects", {
    method: "POST",
    body: JSON.stringify(payload),
  });
  toast("项目已创建");
  closeCreatePanel();
  await loadProjects();
  await loadProject(project.id);
}

async function loadProject(id) {
  selectedProjectId = id;
  selectedArtifact = null;
  const data = await api(`/api/projects/${id}`);
  renderWorkspace(data);
}

function renderWorkspace(data) {
  const {project, artifacts, logs} = data;
  const workspace = document.getElementById("workspace");
  const tabs = artifacts.map((a, idx) => `
    <button class="tab ${idx === 0 ? "active" : ""}" onclick="selectArtifact(${a.id})">${escapeHtml(a.title)}</button>
  `).join("");

  const activeArtifact = artifacts[0];

  workspace.innerHTML = `
    <div class="workspace-header">
      <div>
        <h3>${escapeHtml(project.name)}</h3>
        <p>${escapeHtml(project.goal)}</p>
        <div class="badge">状态：${statusText(project.status)}</div>
      </div>
      <div style="display:flex; gap:8px; flex-wrap:wrap; justify-content:flex-end">
        <button class="primary" onclick="runWorkflow(${project.id})">运行多 Agent 工作流</button>
        <button class="ghost" onclick="downloadExport(${project.id})">导出 JSON</button>
      </div>
    </div>

    ${artifacts.length ? `
      <div class="tabs">${tabs}</div>
      <div id="artifactArea">${renderArtifact(activeArtifact)}</div>
    ` : `
      <div class="empty">
        <h3>还没有生成运营方案</h3>
        <p>点击右上角“运行多 Agent 工作流”。</p>
      </div>
    `}

    <h3 style="margin-top:26px">Agent 协作日志</h3>
    <div class="log-list">
      ${logs.length ? logs.map(l => `
        <div class="log">
          <strong>${escapeHtml(l.agent_name)} · ${escapeHtml(l.step)}</strong>
          <span>${escapeHtml(l.created_at)}</span>
          <p>${escapeHtml(l.message)}</p>
        </div>
      `).join("") : "<p class='muted'>暂无日志</p>"}
    </div>
  `;
}

async function selectArtifact(artifactId) {
  const data = await api(`/api/projects/${selectedProjectId}`);
  const artifact = data.artifacts.find(a => a.id === artifactId);
  document.querySelectorAll(".tab").forEach(btn => btn.classList.remove("active"));
  const btn = Array.from(document.querySelectorAll(".tab")).find(b => b.textContent === artifact.title);
  if (btn) btn.classList.add("active");
  document.getElementById("artifactArea").innerHTML = renderArtifact(artifact);
}

async function runWorkflow(id) {
  const workspace = document.getElementById("workspace");
  workspace.classList.add("loading");
  toast("多 Agent 正在协作生成方案...");
  try {
    await api(`/api/projects/${id}/run`, {method: "POST"});
    toast("运营方案已生成");
    await loadProjects();
    await loadProject(id);
  } catch (err) {
    toast(err.message);
  } finally {
    workspace.classList.remove("loading");
  }
}

async function downloadExport(id) {
  const data = await api(`/api/projects/${id}/export`);
  const blob = new Blob([JSON.stringify(data, null, 2)], {type: "application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `ops-project-${id}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

function renderArtifact(artifact) {
  if (!artifact) return "";
  const c = artifact.content;

  if (artifact.artifact_type === "overview") {
    return `
      <div class="artifact">
        <h4>${escapeHtml(artifact.title)}</h4>
        <div class="cards">
          ${Object.entries(c).map(([k, v]) => `
            <div class="card"><h5>${escapeHtml(k)}</h5><p>${escapeHtml(String(v))}</p></div>
          `).join("")}
        </div>
      </div>
    `;
  }

  if (artifact.artifact_type === "copies" && c.copies) {
    return `
      <div class="artifact">
        <h4>${escapeHtml(artifact.title)}</h4>
        <div class="cards">
          ${c.copies.map(copy => `
            <div class="card">
              <h5>${escapeHtml(copy.channel)}：${escapeHtml(copy.title)}</h5>
              <p>${escapeHtml(copy.body)}</p>
              <p><strong>CTA：</strong>${escapeHtml(copy.cta)}</p>
            </div>
          `).join("")}
        </div>
      </div>
    `;
  }

  if (artifact.artifact_type === "schedule" && c.calendar) {
    return `
      <div class="artifact">
        <h4>${escapeHtml(artifact.title)}</h4>
        <div class="cards">
          ${c.calendar.map(day => `
            <div class="card">
              <h5>${escapeHtml(day.day)} · ${escapeHtml(day.theme)}</h5>
              <p><strong>渠道：</strong>${escapeHtml((day.channels || []).join(" / "))}</p>
              <p><strong>负责人：</strong>${escapeHtml(day.owner)}</p>
              <p><strong>交付物：</strong>${escapeHtml((day.deliverables || []).join("、"))}</p>
              <p><strong>KPI：</strong>曝光 ${day.kpi?.exposure || "-"}，点击 ${day.kpi?.click || "-"}，转化 ${day.kpi?.conversion || "-"}</p>
            </div>
          `).join("")}
        </div>
      </div>
    `;
  }

  if (artifact.artifact_type === "channels" && c.channels) {
    return `
      <div class="artifact">
        <h4>${escapeHtml(artifact.title)}</h4>
        <div class="cards">
          ${c.channels.map(ch => `
            <div class="card">
              <h5>${escapeHtml(ch.name)}</h5>
              <p><strong>目标：</strong>${escapeHtml(ch.goal)}</p>
              <p><strong>动作：</strong>${escapeHtml((ch.actions || []).join("、"))}</p>
              <p><strong>内容角度：</strong>${escapeHtml(ch.content_angle)}</p>
            </div>
          `).join("")}
        </div>
      </div>
    `;
  }

  return `
    <div class="artifact">
      <h4>${escapeHtml(artifact.title)}</h4>
      <pre>${escapeHtml(JSON.stringify(c, null, 2))}</pre>
    </div>
  `;
}

function statusText(status) {
  const map = {
    created: "已创建",
    running: "运行中",
    completed: "已完成",
    failed: "失败",
    blocked: "审核阻断"
  };
  return map[status] || status;
}

function value(id) {
  return document.getElementById(id).value.trim();
}

function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

loadProjects().catch(err => toast(err.message));
