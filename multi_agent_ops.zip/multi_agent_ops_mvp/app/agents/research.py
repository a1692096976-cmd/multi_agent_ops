from typing import Any, Dict
from app.agents.base import BaseAgent
from app.core.memory import BlackboardMemory


class ResearchAgent(BaseAgent):
    name = "ResearchAgent"
    role = "用户洞察 Agent，负责分析目标用户画像、痛点、动机和价值主张。"

    def build_prompt(self, project: Dict[str, Any], memory: BlackboardMemory) -> str:
        plan = memory.get("plan", {})
        return f"""
产品/服务：{project['product']}
目标用户：{project['audience']}
运营目标：{project['goal']}
已有规划：{plan}

请分析用户画像、核心痛点、用户动机、核心价值主张。
"""

    def schema_hint(self) -> str:
        return """
输出 JSON 格式：
{
  "personas": [{"name": "...", "pain_points": ["..."], "motivations": ["..."]}],
  "core_insights": ["..."],
  "value_proposition": "..."
}
"""
