from typing import Any, Dict
from app.agents.base import BaseAgent
from app.core.memory import BlackboardMemory


class SchedulerAgent(BaseAgent):
    name = "SchedulerAgent"
    role = "排期 Agent，负责把策略、渠道和文案整理为 7 天执行日历。"

    def build_prompt(self, project: Dict[str, Any], memory: BlackboardMemory) -> str:
        return f"""
项目：{project['name']}
运营目标：{project['goal']}
渠道策略：{memory.get('channels', {})}
文案：{memory.get('copies', {})}
审核结果：{memory.get('review', {})}

请生成 7 天运营排期，包含每日主题、渠道、负责人、交付物和 KPI。
"""

    def schema_hint(self) -> str:
        return """
输出 JSON 格式：
{
  "calendar": [
    {
      "day": "第 1 天",
      "theme": "...",
      "channels": ["..."],
      "owner": "...",
      "deliverables": ["..."],
      "kpi": {"exposure": 1000, "click": 80, "conversion": 10}
    }
  ]
}
"""
