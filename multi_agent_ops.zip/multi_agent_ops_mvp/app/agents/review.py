from typing import Any, Dict
from app.agents.base import BaseAgent
from app.core.memory import BlackboardMemory


class ReviewAgent(BaseAgent):
    name = "ReviewAgent"
    role = "审核 Agent，负责检查运营方案和文案中的合规、夸大宣传、转化链路风险。"

    def build_prompt(self, project: Dict[str, Any], memory: BlackboardMemory) -> str:
        return f"""
运营目标：{project['goal']}
渠道策略：{memory.get('channels', {})}
文案内容：{memory.get('copies', {})}

请审核风险，给出风险等级、风险点、修改建议，并判断是否可进入排期。
"""

    def schema_hint(self) -> str:
        return """
输出 JSON 格式：
{
  "risk_level": "低/中低/中/高",
  "risks": [{"type": "...", "description": "...", "suggestion": "..."}],
  "approved": true,
  "final_note": "..."
}
"""
