from typing import Any, Dict
from app.agents.base import BaseAgent
from app.core.memory import BlackboardMemory


class CopywriterAgent(BaseAgent):
    name = "CopywriterAgent"
    role = "内容生产 Agent，负责根据用户洞察和渠道策略生成多平台运营文案。"

    def build_prompt(self, project: Dict[str, Any], memory: BlackboardMemory) -> str:
        return f"""
产品/服务：{project['product']}
目标用户：{project['audience']}
语气：{project['tone']}
用户洞察：{memory.get('research', {})}
渠道策略：{memory.get('channels', {})}

请生成多渠道运营文案，每条包括渠道、标题、正文、CTA。
"""

    def schema_hint(self) -> str:
        return """
输出 JSON 格式：
{
  "copies": [{"channel": "...", "title": "...", "body": "...", "cta": "..."}]
}
"""
