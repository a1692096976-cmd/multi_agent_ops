from typing import Any, Dict
from app.agents.base import BaseAgent
from app.core.memory import BlackboardMemory


class AnalystAgent(BaseAgent):
    name = "AnalystAgent"
    role = "数据分析 Agent，负责预测指标、设计复盘指标和下一步优化动作。"

    def build_prompt(self, project: Dict[str, Any], memory: BlackboardMemory) -> str:
        return f"""
项目：{project['name']}
运营目标：{project['goal']}
渠道策略：{memory.get('channels', {})}
排期：{memory.get('schedule', {})}

请预测活动效果，设计复盘指标，给出优化建议和下一步动作。
"""

    def schema_hint(self) -> str:
        return """
输出 JSON 格式：
{
  "forecast": {"total_exposure": 0, "total_click": 0, "estimated_conversions": 0, "conversion_rate": "...", "confidence": "..."},
  "metrics": ["..."],
  "optimization": ["..."],
  "next_actions": ["..."]
}
"""
