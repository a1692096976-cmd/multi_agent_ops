from typing import Any, Dict
from app.agents.base import BaseAgent
from app.core.memory import BlackboardMemory


class PlannerAgent(BaseAgent):
    name = "PlannerAgent"
    role = "运营规划 Agent，负责把模糊目标拆解为可执行任务和阶段里程碑。"

    def build_prompt(self, project: Dict[str, Any], memory: BlackboardMemory) -> str:
        return f"""
项目名称：{project['name']}
产品/服务：{project['product']}
目标用户：{project['audience']}
运营目标：{project['goal']}
预算：{project['budget']}
语气：{project['tone']}

请生成运营策略、阶段里程碑和任务清单。
"""

    def schema_hint(self) -> str:
        return """
输出 JSON 格式：
{
  "strategy": "...",
  "milestones": ["..."],
  "tasks": [{"name": "...", "priority": "高/中/低", "owner": "..."}]
}
"""
