from typing import Any, Dict
from app.agents.base import BaseAgent
from app.core.memory import BlackboardMemory


class ChannelAgent(BaseAgent):
    name = "ChannelAgent"
    role = "渠道策略 Agent，负责设计渠道组合、动作路径和转化漏斗。"

    def build_prompt(self, project: Dict[str, Any], memory: BlackboardMemory) -> str:
        return f"""
运营目标：{project['goal']}
预算：{project['budget']}
用户洞察：{memory.get('research', {})}

请为该项目选择合适运营渠道，并设计从曝光到转化的漏斗。
"""

    def schema_hint(self) -> str:
        return """
输出 JSON 格式：
{
  "channels": [{"name": "...", "goal": "...", "actions": ["..."], "content_angle": "..."}],
  "funnel": ["..."]
}
"""
