from typing import Any, Dict
from app.core.memory import BlackboardMemory
from app.core.llm import BaseLLM, safe_json_loads


class AgentResult(dict):
    pass


class BaseAgent:
    name = "BaseAgent"
    role = "基础 Agent"

    def __init__(self, llm: BaseLLM):
        self.llm = llm

    def system_prompt(self) -> str:
        return f"你是 {self.name}，角色是：{self.role}。请输出严格 JSON。"

    def build_prompt(self, project: Dict[str, Any], memory: BlackboardMemory) -> str:
        raise NotImplementedError

    def schema_hint(self) -> str:
        return "请输出 JSON，不要输出 Markdown。"

    def run(self, project: Dict[str, Any], memory: BlackboardMemory) -> AgentResult:
        prompt = self.build_prompt(project, memory)
        raw = self.llm.generate(self.system_prompt(), prompt, self.schema_hint())
        data = safe_json_loads(raw)
        return AgentResult(data)
