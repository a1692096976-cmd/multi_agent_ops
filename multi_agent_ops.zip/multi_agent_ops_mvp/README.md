# 多 Agent 协同运营自动化系统 MVP

这是一个完整可运行的 **多 Agent 协同运营自动化系统** MVP。它模拟真实运营团队的协作流程：用户输入运营目标后，系统由多个 Agent 自动完成目标拆解、用户洞察、渠道策略、内容生成、风控审核、排期计划、指标预测和复盘建议。

项目默认使用 **本地规则模型 Mock LLM**，不需要 API Key 即可运行；如果你有 OpenAI API Key，也可以切换为真实大模型模式。

---

## 一、核心能力

系统包含 7 个 Agent：

1. **PlannerAgent 运营规划 Agent**
   - 拆解运营目标
   - 输出阶段目标、关键任务、优先级

2. **ResearchAgent 用户洞察 Agent**
   - 分析目标用户、痛点、卖点
   - 输出用户画像和机会点

3. **ChannelAgent 渠道策略 Agent**
   - 自动选择适合的运营渠道
   - 给出各渠道动作和内容方向

4. **CopywriterAgent 内容生产 Agent**
   - 自动生成小红书、公众号、短信、社群、邮件等运营文案
   - 支持不同语气和目标

5. **ReviewAgent 审核 Agent**
   - 检查夸大宣传、违规表述、信息缺失、转化风险
   - 给出修改建议

6. **SchedulerAgent 排期 Agent**
   - 生成 7 天运营执行日历
   - 标记负责人、渠道、目标、素材

7. **AnalystAgent 数据分析 Agent**
   - 预测曝光、点击、转化
   - 给出复盘指标和优化建议

---

## 二、技术栈

- Python 3.10+
- FastAPI
- SQLite
- Vanilla JS 前端
- Jinja2 模板
- 可选 OpenAI API 接入

---

## 三、快速运行

### 1. 解压项目

```bash
unzip multi_agent_ops_mvp.zip
cd multi_agent_ops_mvp
```

### 2. 创建虚拟环境

```bash
python -m venv .venv
```

Windows：

```bash
.venv\Scripts\activate
```

macOS / Linux：

```bash
source .venv/bin/activate
```

### 3. 安装依赖

```bash
pip install -r requirements.txt
```

### 4. 启动服务

```bash
python run.py
```

打开浏览器访问：

```text
http://127.0.0.1:8000
```

---

## 四、可选：接入 OpenAI

默认不需要 API Key。若希望使用真实大模型，可创建 `.env` 文件：

```bash
cp .env.example .env
```

然后填写：

```env
LLM_PROVIDER=openai
OPENAI_API_KEY=你的_key
OPENAI_MODEL=gpt-4o-mini
```

重新启动：

```bash
python run.py
```

---

## 五、典型使用场景

可以输入类似目标：

```text
为一个面向大学生的 AI 简历优化工具做 7 天冷启动运营，目标是在一周内获取 300 个注册用户。
```

也可以输入：

```text
为本地咖啡店设计五一假期促销活动，目标是提高到店客流和社群复购。
```

系统会自动生成：

- 项目总览
- 多 Agent 协作过程日志
- 用户画像
- 渠道策略
- 多平台运营文案
- 风控审核意见
- 7 天运营排期
- 指标预测
- 复盘建议

---

## 六、项目结构

```text
multi_agent_ops_mvp/
├─ app/
│  ├─ main.py                  # FastAPI 入口
│  ├─ config.py                # 配置
│  ├─ schemas.py               # Pydantic 模型
│  ├─ agents/                  # 多 Agent
│  ├─ core/                    # LLM、记忆、编排器
│  ├─ db/                      # SQLite 数据库
│  ├─ services/                # 业务服务
│  ├─ templates/               # 页面模板
│  └─ static/                  # 前端 JS/CSS
├─ data/                       # SQLite 数据文件
├─ tests/                      # 简单测试
├─ run.py                      # 启动脚本
├─ requirements.txt
├─ .env.example
└─ README.md
```

---

## 七、MVP 亮点

- 不只是聊天机器人，而是完整的运营工作流
- 有明确的多 Agent 职责划分
- 有黑板记忆机制，Agent 之间共享上下文
- 有日志记录，可展示 Agent 协作过程
- 有 SQLite 持久化
- 可导出完整运营方案 JSON
- 无 API Key 也能跑通
- 可平滑切换到真实 LLM

---

## 八、接口说明

### 创建项目

```http
POST /api/projects
```

### 运行 Agent 工作流

```http
POST /api/projects/{project_id}/run
```

### 查看项目详情

```http
GET /api/projects/{project_id}
```

### 查看 Agent 日志

```http
GET /api/projects/{project_id}/logs
```

### 导出运营方案

```http
GET /api/projects/{project_id}/export
```

---

## 九、后续可扩展方向

- 接入飞书 / 企业微信 / Slack，实现任务推送
- 接入真实数据源，如订单表、广告后台、CRM
- 增加 RAG 知识库，让 Agent 读取企业 SOP
- 接入定时任务，实现自动日报和周报
- 接入邮件或私域社群工具，形成自动执行闭环
- 增加人工审核节点，避免 Agent 直接发布内容

---

## 十、适合写在申请表里的成果描述

我构建了一个多 Agent 协同运营自动化系统，用来解决小团队在运营活动中目标拆解慢、内容生产分散、排期混乱、复盘不及时的问题。系统将运营流程拆分为规划、用户洞察、渠道策略、内容生成、风险审核、排期执行和数据分析等多个 Agent，每个 Agent 负责一个明确环节，并通过共享黑板记忆机制传递上下文。用户只需要输入运营目标，系统即可自动生成完整的 7 天运营方案，包括用户画像、渠道动作、推广文案、执行日历、风险提示和指标预测。该 MVP 已支持本地运行和 SQLite 持久化，可在无 API Key 情况下完成端到端演示，也可切换到真实大模型模式。预计在小团队运营场景中，可减少 60% 以上的方案整理和文案初稿时间。
