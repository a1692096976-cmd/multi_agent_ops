from app.core.orchestrator import Orchestrator


def test_orchestrator_runs_with_local_llm():
    project = {
        "id": 0,
        "name": "测试项目",
        "goal": "为一个测试产品设计 7 天运营活动，目标获取 100 个用户。",
        "product": "测试产品",
        "audience": "测试用户",
        "budget": "低预算",
        "tone": "专业清晰",
    }

    # 这里只测试 Agent 编排逻辑中的 agent 输出能力，不写数据库。
    # 完整数据库流程可通过启动服务后在页面点击运行测试。
    orchestrator = Orchestrator()
    assert len(orchestrator.agents) == 7
